package com.example.demo.servlet;

public class SimpleEchoServlet{
    
}